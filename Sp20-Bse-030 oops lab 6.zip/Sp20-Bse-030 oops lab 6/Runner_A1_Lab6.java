/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Cyber World
 */
public class Runner_A1_Lab6 {
    public static void main(String[]args){
        Calculator.sum(3, 7);
        Calculator.Multiply(7.9, 4.4);
        Calculator.Devide(20, 5);
         Calculator.Mod(-7);
        Calculator.Sin(30);
        Calculator.Cos(30);
        Calculator.Tan(30);
    }
    
}
