/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numofobj;

/**
 *
 * @author Cyber World
 */
public class NumofObj {

   static int count = 0;
   static int counttotal = 0;
   static int Numofobject ;
    
  public NumofObj(int x){
      Numofobject = x;
      if(this == null){
          counttotal++;
      }
      else{
          count++;
      }
      
      
      
  }
  public void Display(){
      System.out.println("you have created "+count++ +" objects");
      System.out.println("Number of destroyed objects are "+counttotal++);
  }

    

    
    
}
