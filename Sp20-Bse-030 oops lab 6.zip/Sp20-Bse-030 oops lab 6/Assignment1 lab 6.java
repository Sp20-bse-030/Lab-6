/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Cyber World
 */
public class Calculator {
    double  a;
    double   b;
    public Calculator(){
        a = 9;
        b = 4;
    }
    public Calculator(double x, double y){
        a = x;
        b = y;
    }
    public static void sum(double x, double y){
        double c = x+y;
        System.out.println("sum is "+c);
    }
    public static void Multiply(double x, double y){
        double d = x*y;
        System.out.println("product is "+d);
    }
    public static void Devide(double x, double y){
        double e = x/y;
        System.out.println("division is "+e);
    }
     public static void Mod(double x){
         if(x<0){
             double  f = x*-1;
             System.out.println("modulus is " +f);
             
         }
         else{
             System.out.println("Modulus is " +x);
         }
   
     }
     public static double Sin(double x){
         double a = Math.toRadians(x);
         System.out.println("sin is "+Math.sin(a));
         return a;
         
     }
      public static double Cos(double x){
         double a = Math.toRadians(x);
         System.out.println("cos is "+Math.cos(a));
         return a;
      }   
      public static void Tan(double x){
          double a = Math.toRadians(x);
          System.out.println("tan is " +Math.tan(a));
         
          
      }
}
