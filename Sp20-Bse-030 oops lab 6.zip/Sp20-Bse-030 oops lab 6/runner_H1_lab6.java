/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savingaccount;

/**
 *
 * @author Cyber World
 */
public class runner_H1_lab6 {
    public static void main(String[]args){
        SavingAccount A1 = new SavingAccount();
        //SavingAccount A2 = new SavingAccount(5,5000);
       A1.CalMonthlyIntrest();
       A1.setanulalIrate(4);
       A1.CalMonthlyIntrest();
       SavingAccount A2 = new SavingAccount();
       A2.setsavingbalance(3000);
       A2.CalMonthlyIntrest();
       A2.setanulalIrate(4);
       A2.CalMonthlyIntrest();
       
        
    }
    
}
