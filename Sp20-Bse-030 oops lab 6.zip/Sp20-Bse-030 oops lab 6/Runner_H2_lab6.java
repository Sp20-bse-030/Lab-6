/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package numofobj;

/**
 *
 * @author Cyber World
 */
public class Runner_A2_lab6 {
    public static void main(String[]args){
        NumofObj a1 = new  NumofObj(4);
        NumofObj a2 = new  NumofObj(5);
        NumofObj a3 = new  NumofObj(6);
        NumofObj a4 = new  NumofObj(8);
        NumofObj a5 = new  NumofObj(0);
        
        a5.Display();
        a4 = null;
        a3.Display();
        a2 = null;
        a1.Display();
        
        
        
    }
        
    
}
