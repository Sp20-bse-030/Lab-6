/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package savingaccount;

/**
 *
 * @author Cyber World
 */
public class SavingAccount {

 static double annualInterestrate;
 static private double savingbalance;
 public SavingAccount(){
      annualInterestrate = 3;
      savingbalance = 2000;
 }
 public SavingAccount(double x, double y){
     annualInterestrate = x;
     savingbalance = y;
 }
 
 public void setanulalIrate(int x){
     annualInterestrate = x;
 }
 public double getanulalIrate(){
     return annualInterestrate;
 }
  public void setsavingbalance(int y){
     savingbalance = y;
 }
 public double getsavingbalance(){
     return savingbalance;
 }
 public double CalMonthlyIntrest(){
     double interest = savingbalance*annualInterestrate/12;
     System.out.println("interest is "+ interest);
     savingbalance += interest;
     System.out.println("new balance is " + savingbalance);
     return interest;
     
 }   
}
